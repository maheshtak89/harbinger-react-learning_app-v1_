import React, { Component } from 'react';
class HomePage extends Component {
    render() { 
        return ( 
            <div>
                <img src={require('./../images/harbinger.jpg')} alt="Harbinger" height = "30%" width="30%"/>
            </div>
         );
    }
}
 
export default HomePage;